import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;
import java.util.Set;

class Student {

	String Name;
	int roll_number;
	double total_marks;
	Student(int roll,String Name,double total)
	{
		this.Name=Name;
		this.roll_number=roll;
		this.total_marks=total;
	}
}
public class Solution {
	final int x=20000;
	HashMap<Integer,Student> hmap = new HashMap<Integer,Student>();
	//ArrayList<Student> al=new ArrayList<Student>();
	private Object Student; 
	
	void put(Student s,int a)
	{
		
        hmap.put(a,s);	
       // al.add(s);
       
	}
	void get(int s,int j)
	{
		
		
		if(hmap.containsKey(s))
		{
			//System.out.println("^^");
			Student s2=hmap.get(s);
			switch(j)
			{
			case 1:System.out.println(s2.Name);
					break;
			case 2:System.out.println(s2.total_marks);
					break;
			}
		}
		else
		{
		System.out.println("Student doesn't exists...");
		}
        
	}
	
	public static void main(String args[])
	{
		Solution S=new Solution();
	Scanner scan=new Scanner(System.in);
	int x=Integer.parseInt(scan.nextLine());
	int count=0;
	while(scan.hasNext()&&count<x)
		{
			String s=scan.nextLine();
			String[] s1=s.split(",");
			//int y=S.hash(s1[0]);
			//System.out.println(y);
			Student stu=new Student(Integer.parseInt(s1[0]),s1[1],Double.parseDouble(s1[2]));
			S.put(stu,Integer.parseInt(s1[0]));
			count++;
			
		}
	//System.out.println("***");
	int y=Integer.parseInt(scan.nextLine());
	int count1=0;
	while(scan.hasNext()&&count1<y)
	{
		String s=scan.nextLine();
		String[] s1=s.split(" ");
		S.get(Integer.parseInt(s1[1]),Integer.parseInt(s1[2]));
		count1++;
		
	}
	
	}
	

}
