import java.util.Scanner;

class Student
{
	String Name;
	int roll_number;
	double total_marks;
	Student(int roll,String Name,double total)
	{
		this.Name=Name;
		this.roll_number=roll;
		this.total_marks=total;
	}
}
class Node
{
	public Student key;
	public double value;
	Node left;
	public Node right;
	public Node(Student key,double value)
	{
		this.key=key;
		this.value=value;
	}
}
public class Solution {
	Node root;
	public void put(Student key,double value)
	{
		root=put(root,key,value);
		
	}
	public Node put(Node node,Student Key,double value)
	{
		if(node==null)
			return new Node(Key,value);
		if(Key.total_marks<node.key.total_marks)
			node.left=put(node.left,Key,value);
		if(Key.total_marks>node.key.total_marks)
			node.right=put(node.right,Key,value);
		if(Key.total_marks==node.key.total_marks)
			node.value=value;
		return node;
		
	}
	public double get(Student Key)
	{
		Node node=root;
		while(node!=null)
		{
			if(Key.total_marks<node.key.total_marks)
				node=node.left;
			else if(Key.total_marks>node.key.total_marks)
				node=node.right;
			else
				return node.value;
			
		}
		return 0;
	}
	public static void main(String args[])
	{
		Solution Sol=new Solution();
		Scanner scan =new Scanner(System.in);
		int x=Integer.parseInt(scan.nextLine());
		int count=0;
		while(scan.hasNext()&&count<x)
			{
				String s=scan.nextLine();
				String[] s1=s.split(",");
				Student stu=new Student(Integer.parseInt(s1[0]),s1[1],Double.parseDouble(s1[2]));
				Sol.put(stu,Double.parseDouble(s1[2]));
				count++;
				
			}
		
	}
}
